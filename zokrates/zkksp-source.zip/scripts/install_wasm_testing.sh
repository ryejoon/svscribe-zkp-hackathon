apt-get update && apt-get install curl firefox-esr -y --no-install-recommends
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh