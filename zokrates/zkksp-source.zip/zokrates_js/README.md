# zokrates.js

JavaScript bindings for [ZoKrates](https://github.com/Zokrates/ZoKrates) project. 

```bash
npm install zokrates-js
```

Check the offical [ZoKrates documentation](https://zokrates.github.io/toolbox/zokrates_js.html) for more details.
