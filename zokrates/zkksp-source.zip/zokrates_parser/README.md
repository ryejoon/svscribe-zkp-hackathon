# zokrates_parser

Formal grammar specification of the ZoKrates DSL in PEG (Pest).
