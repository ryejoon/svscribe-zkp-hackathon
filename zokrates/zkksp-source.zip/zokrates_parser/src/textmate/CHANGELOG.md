## [0.0.2] - 2021-03-01

- Add new syntax for ZoKrates 0.7.1

## [0.0.1] - 2021-03-01

- Initial release