### ZoKrates Ace Mode (Syntax Highlighting for Ace/Brace)

[Ace](https://ace.c9.io/) Edit Mode for [ZoKrates DSL](https://github.com/Zokrates/ZoKrates).
Compatible with browserify version of the ace editor, [brace](https://www.npmjs.com/package/brace).