# Command Line Tool

ZoKrates provides a command line interface.
You can see an overview of the available subcommands by running

```sh
zokrates
```

You can get help about a particular subcommand with `--help`, for example:
```sh
zokrates compile --help
```