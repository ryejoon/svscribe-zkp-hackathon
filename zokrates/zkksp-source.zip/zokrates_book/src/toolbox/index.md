# ZoKrates Reference

The reference covers the details of the ZoKrates toolbox beyond the ZoKrates language.